package org.boilit.ebm;

/**
 * @author Boilit
 * @see
 */
public enum OutputMode {
    BYTES,
    CHARS
}
